create database inventorySystem;

use inventorySystem;



create table Products(
ProductID int primary key identity,
ProductName varchar(150) not null,
PDescription varchar(450),
Category varchar(50),
UnitPrice decimal(10,2) not null,
);


Create table Suppliers(
SupplierID int Primary key identity,
SupplierName varchar(100),
ContactName varchar(100),
Address varchar(200),
City varchar(50),
Phone varchar(20),
Email varchar(100)
);




create table Inventory(
InventoryID int primary key identity,
ProductID int not null,
QuantityInStock int not null,
location varchar(60),
foreign key (ProductID) references products(productID)
);

create table PurchaseOrders(
orderID int primary key identity,
supplierID int not null,
FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID),
TotalAmount decimal (10,2)
);

Create table orderDetails(
orderDetailID int primary key identity,
OrderID int not null,
ProductID int not null,
Quantity int not null,
UnitPrice Decimal (10,2) not null,
FOREIGN KEY (OrderID) REFERENCES PurchaseOrders(OrderID),
FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);


CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY identity,
    CustomerName VARCHAR(100) NOT NULL,
    ContactName VARCHAR(100),
    Email VARCHAR(100),
    Phone VARCHAR(20)
);

CREATE TABLE SalesOrders (
    OrderID INT PRIMARY KEY identity,
    CustomerID INT NOT NULL,
    OrderDate DATETIME DEFAULT GETDATE(),
    TotalAmount DECIMAL(10,2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);
