document.addEventListener('DOMContentLoaded', function() {
    // Tab Switching Functionality
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked button
            button.classList.add('active');
            
            // Show corresponding content
            const tabId = button.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });

    // Modal Functionality
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const closeBtn = document.querySelector('.close-btn');
    
    // Close modal when clicking X or outside
    closeBtn.addEventListener('click', () => modal.style.display = 'none');
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Sample Data (would come from backend in real app)
    let products = [
        { ProductID: 1, ProductName: "Laptop", PDescription: "High performance laptop", Category: "Electronics", UnitPrice: 999.99 },
        { ProductID: 2, ProductName: "Desk Chair", PDescription: "Ergonomic office chair", Category: "Furniture", UnitPrice: 149.99 }
    ];

    let suppliers = [
        { SupplierID: 1, SupplierName: "Tech Distributors", ContactName: "John Smith", Address: "123 Tech St", City: "San Francisco", Phone: "555-1234", Email: "john@techdist.com" },
        { SupplierID: 2, SupplierName: "Office Solutions", ContactName: "Sarah Johnson", Address: "456 Office Ave", City: "New York", Phone: "555-5678", Email: "sarah@officesol.com" }
    ];

    let inventory = [
        { InventoryID: 1, ProductID: 1, QuantityInStock: 15, location: "Warehouse A" },
        { InventoryID: 2, ProductID: 2, QuantityInStock: 8, location: "Warehouse B" }
    ];

    let customers = [
        { CustomerID: 1, CustomerName: "ABC Corporation", ContactName: "Michael Brown", Email: "michael@abc.com", Phone: "555-9012" },
        { CustomerID: 2, CustomerName: "XYZ Enterprises", ContactName: "Emily Davis", Email: "emily@xyz.com", Phone: "555-3456" }
    ];

    let purchaseOrders = [
        { orderID: 1, supplierID: 1, TotalAmount: 2999.97 }
    ];

    let salesOrders = [
        { OrderID: 1, CustomerID: 1, OrderDate: "2023-05-15", TotalAmount: 1499.98 }
    ];

    let orderDetails = [
        { orderDetailID: 1, OrderID: 1, ProductID: 1, Quantity: 3, UnitPrice: 999.99 }
    ];

    // Populate Tables
    function populateProductsTable() {
        const tableBody = document.getElementById('products-table-body');
        tableBody.innerHTML = '';
        
        products.forEach(product => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${product.ProductID}</td>
                <td>${product.ProductName}</td>
                <td>${product.PDescription || 'N/A'}</td>
                <td>${product.Category || 'N/A'}</td>
                <td>$${product.UnitPrice.toFixed(2)}</td>
                <td>
                    <button class="btn-primary edit-btn" data-id="${product.ProductID}">Edit</button>
                    <button class="btn-danger delete-btn" data-id="${product.ProductID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    function populateSuppliersTable() {
        const tableBody = document.getElementById('suppliers-table-body');
        tableBody.innerHTML = '';
        
        suppliers.forEach(supplier => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${supplier.SupplierID}</td>
                <td>${supplier.SupplierName}</td>
                <td>${supplier.ContactName}</td>
                <td>${supplier.Address}</td>
                <td>${supplier.City}</td>
                <td>${supplier.Phone}</td>
                <td>${supplier.Email}</td>
                <td>
                    <button class="btn-primary edit-btn" data-id="${supplier.SupplierID}">Edit</button>
                    <button class="btn-danger delete-btn" data-id="${supplier.SupplierID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    function populateInventoryTable() {
        const tableBody = document.getElementById('inventory-table-body');
        tableBody.innerHTML = '';
        
        inventory.forEach(item => {
            const product = products.find(p => p.ProductID === item.ProductID);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.InventoryID}</td>
                <td>${item.ProductID} (${product ? product.ProductName : 'N/A'})</td>
                <td>${item.QuantityInStock}</td>
                <td>${item.location}</td>
                <td>
                    <button class="btn-primary edit-btn" data-id="${item.InventoryID}">Edit</button>
                    <button class="btn-danger delete-btn" data-id="${item.InventoryID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    function populateCustomersTable() {
        const tableBody = document.getElementById('customers-table-body');
        tableBody.innerHTML = '';
        
        customers.forEach(customer => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${customer.CustomerID}</td>
                <td>${customer.CustomerName}</td>
                <td>${customer.ContactName}</td>
                <td>${customer.Email}</td>
                <td>${customer.Phone}</td>
                <td>
                    <button class="btn-primary edit-btn" data-id="${customer.CustomerID}">Edit</button>
                    <button class="btn-danger delete-btn" data-id="${customer.CustomerID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    function populatePurchaseOrdersTable() {
        const tableBody = document.getElementById('purchase-orders-table-body');
        tableBody.innerHTML = '';
        
        purchaseOrders.forEach(order => {
            const supplier = suppliers.find(s => s.SupplierID === order.supplierID);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.orderID}</td>
                <td>${order.supplierID} (${supplier ? supplier.SupplierName : 'N/A'})</td>
                <td>$${order.TotalAmount.toFixed(2)}</td>
                <td>
                    <button class="btn-primary view-btn" data-id="${order.orderID}">View</button>
                    <button class="btn-danger delete-btn" data-id="${order.orderID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    function populateSalesOrdersTable() {
        const tableBody = document.getElementById('sales-orders-table-body');
        tableBody.innerHTML = '';
        
        salesOrders.forEach(order => {
            const customer = customers.find(c => c.CustomerID === order.CustomerID);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.OrderID}</td>
                <td>${order.CustomerID} (${customer ? customer.CustomerName : 'N/A'})</td>
                <td>${order.OrderDate}</td>
                <td>$${order.TotalAmount.toFixed(2)}</td>
                <td>
                    <button class="btn-primary view-btn" data-id="${order.OrderID}">View</button>
                    <button class="btn-danger delete-btn" data-id="${order.OrderID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    function populateOrderDetailsTable(orderId) {
        const tableBody = document.getElementById('order-details-table-body');
        tableBody.innerHTML = '';
        
        const details = orderDetails.filter(detail => detail.OrderID == orderId);
        details.forEach(detail => {
            const product = products.find(p => p.ProductID === detail.ProductID);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${detail.orderDetailID}</td>
                <td>${detail.OrderID}</td>
                <td>${detail.ProductID} (${product ? product.ProductName : 'N/A'})</td>
                <td>${detail.Quantity}</td>
                <td>$${detail.UnitPrice.toFixed(2)}</td>
                <td>
                    <button class="btn-primary edit-btn" data-id="${detail.orderDetailID}">Edit</button>
                    <button class="btn-danger delete-btn" data-id="${detail.orderDetailID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    // Initialize the page
    populateProductsTable();
    populateSuppliersTable();
    populateInventoryTable();
    populateCustomersTable();
    populatePurchaseOrdersTable();
    populateSalesOrdersTable();

    // Add Product Form
    document.getElementById('add-product-btn').addEventListener('click', () => {
        modalTitle.textContent = 'Add New Product';
        modalBody.innerHTML = `
            <form id="product-form">
                <div class="form-group">
                    <label for="product-name">Product Name*</label>
                    <input type="text" id="product-name" required>
                </div>
                <div class="form-group">
                    <label for="product-description">Description</label>
                    <textarea id="product-description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="product-category">Category</label>
                    <input type="text" id="product-category">
                </div>
                <div class="form-group">
                    <label for="product-price">Unit Price*</label>
                    <input type="number" id="product-price" step="0.01" min="0" required>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-primary" id="save-product">Save</button>
                    <button type="button" class="btn-danger" id="cancel-product">Cancel</button>
                </div>
            </form>
        `;
        modal.style.display = 'block';

        document.getElementById('cancel-product').addEventListener('click', () => {
            modal.style.display = 'none';
        });

        document.getElementById('save-product').addEventListener('click', () => {
            // Validate form
            if (!document.getElementById('product-name').value || !document.getElementById('product-price').value) {
                alert('Please fill in all required fields');
                return;
            }

            // Create new product
            const newId = products.length > 0 ? Math.max(...products.map(p => p.ProductID)) + 1 : 1;
            const newProduct = {
                ProductID: newId,
                ProductName: document.getElementById('product-name').value,
                PDescription: document.getElementById('product-description').value,
                Category: document.getElementById('product-category').value,
                UnitPrice: parseFloat(document.getElementById('product-price').value)
            };
            
            products.push(newProduct);
            populateProductsTable();
            modal.style.display = 'none';
        });
    });

    // Similar forms can be created for other entities
    // Add Supplier Form
    document.getElementById('add-supplier-btn').addEventListener('click', () => {
        modalTitle.textContent = 'Add New Supplier';
        modalBody.innerHTML = `
            <form id="supplier-form">
                <div class="form-group">
                    <label for="supplier-name">Supplier Name</label>
                    <input type="text" id="supplier-name">
                </div>
                <div class="form-group">
                    <label for="contact-name">Contact Name</label>
                    <input type="text" id="contact-name">
                </div>
                <div class="form-group">
                    <label for="supplier-address">Address</label>
                    <input type="text" id="supplier-address">
                </div>
                <div class="form-group">
                    <label for="supplier-city">City</label>
                    <input type="text" id="supplier-city">
                </div>
                <div class="form-group">
                    <label for="supplier-phone">Phone</label>
                    <input type="text" id="supplier-phone">
                </div>
                <div class="form-group">
                    <label for="supplier-email">Email</label>
                    <input type="email" id="supplier-email">
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-primary" id="save-supplier">Save</button>
                    <button type="button" class="btn-danger" id="cancel-supplier">Cancel</button>
                </div>
            </form>
        `;
        modal.style.display = 'block';

        document.getElementById('cancel-supplier').addEventListener('click', () => {
            modal.style.display = 'none';
        });

        document.getElementById('save-supplier').addEventListener('click', () => {
            const newId = suppliers.length > 0 ? Math.max(...suppliers.map(s => s.SupplierID)) + 1 : 1;
            const newSupplier = {
                SupplierID: newId,
                SupplierName: document.getElementById('supplier-name').value,
                ContactName: document.getElementById('contact-name').value,
                Address: document.getElementById('supplier-address').value,
                City: document.getElementById('supplier-city').value,
                Phone: document.getElementById('supplier-phone').value,
                Email: document.getElementById('supplier-email').value
            };
            
            suppliers.push(newSupplier);
            populateSuppliersTable();
            modal.style.display = 'none';
        });
    });

    // Add Inventory Form
    document.getElementById('add-inventory-btn').addEventListener('click', () => {
        modalTitle.textContent = 'Add Inventory Item';
        modalBody.innerHTML = `
            <form id="inventory-form">
                <div class="form-group">
                    <label for="inventory-product">Product*</label>
                    <select id="inventory-product" required>
                        <option value="">Select Product</option>
                        ${products.map(p => `<option value="${p.ProductID}">${p.ProductID} - ${p.ProductName}</option>`).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label for="inventory-quantity">Quantity*</label>
                    <input type="number" id="inventory-quantity" min="0" required>
                </div>
                <div class="form-group">
                    <label for="inventory-location">Location</label>
                    <input type="text" id="inventory-location">
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-primary" id="save-inventory">Save</button>
                    <button type="button" class="btn-danger" id="cancel-inventory">Cancel</button>
                </div>
            </form>
        `;
        modal.style.display = 'block';

        document.getElementById('cancel-inventory').addEventListener('click', () => {
            modal.style.display = 'none';
        });

        document.getElementById('save-inventory').addEventListener('click', () => {
            if (!document.getElementById('inventory-product').value || !document.getElementById('inventory-quantity').value) {
                alert('Please fill in all required fields');
                return;
            }

            const newId = inventory.length > 0 ? Math.max(...inventory.map(i => i.InventoryID)) + 1 : 1;
            const newInventory = {
                InventoryID: newId,
                ProductID: parseInt(document.getElementById('inventory-product').value),
                QuantityInStock: parseInt(document.getElementById('inventory-quantity').value),
                location: document.getElementById('inventory-location').value
            };
            
            inventory.push(newInventory);
            populateInventoryTable();
            modal.style.display = 'none';
        });
    });

    // View Order Details
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('view-btn')) {
            const orderId = e.target.getAttribute('data-id');
            populateOrderDetailsTable(orderId);
            
            // Hide all tabs and show order details
            tabContents.forEach(content => content.style.display = 'none');
            document.getElementById('order-details-section').style.display = 'block';
        }
    });

    // Back to Orders button
    document.getElementById('back-to-orders-btn').addEventListener('click', function() {
        document.getElementById('order-details-section').style.display = 'none';
        tabContents.forEach(content => content.style.display = 'none');
        document.querySelector('.tab-btn.active').click();
    });

    // Similar forms can be added for Customers, Purchase Orders, and Sales Orders
});



////////////////////////////////////////////////////////////////////////////////




document.addEventListener('DOMContentLoaded', function() {
    // Tab Switching Functionality
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            button.classList.add('active');
            const tabId = button.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
            
            // Refresh data when switching to products tab
            if (tabId === 'products') {
                fetchProducts();
            }
        });
    });

    // Modal Functionality
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const closeBtn = document.querySelector('.close-btn');
    
    closeBtn.addEventListener('click', () => modal.style.display = 'none');
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // API Base URL
    const API_BASE_URL = 'http://localhost:5000/api/products';

    // Current product being edited
    let currentProductId = null;

    // Fetch all products
    async function fetchProducts() {
        try {
            const response = await fetch(API_BASE_URL);
            if (!response.ok) {
                throw new Error('Failed to fetch products');
            }
            const products = await response.json();
            populateProductsTable(products);
        } catch (error) {
            console.error('Error fetching products:', error);
            alert('Error loading products. Please check console for details.');
        }
    }

    // Populate Products Table
    function populateProductsTable(products) {
        const tableBody = document.getElementById('products-table-body');
        tableBody.innerHTML = '';
        
        products.forEach(product => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${product.ProductID}</td>
                <td>${product.ProductName}</td>
                <td>${product.PDescription || 'N/A'}</td>
                <td>${product.Category || 'N/A'}</td>
                <td>$${product.UnitPrice.toFixed(2)}</td>
                <td>
                    <button class="btn-primary edit-btn" data-id="${product.ProductID}">Edit</button>
                    <button class="btn-danger delete-btn" data-id="${product.ProductID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });

        // Add event listeners to edit and delete buttons
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = e.target.getAttribute('data-id');
                showEditProductForm(productId);
            });
        });

        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = e.target.getAttribute('data-id');
                deleteProduct(productId);
            });
        });
    }

    // Show Add Product Form
    document.getElementById('add-product-btn').addEventListener('click', () => {
        currentProductId = null;
        modalTitle.textContent = 'Add New Product';
        modalBody.innerHTML = `
            <form id="product-form">
                <div class="form-group">
                    <label for="product-name">Product Name*</label>
                    <input type="text" id="product-name" required>
                </div>
                <div class="form-group">
                    <label for="product-description">Description</label>
                    <textarea id="product-description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="product-category">Category</label>
                    <input type="text" id="product-category">
                </div>
                <div class="form-group">
                    <label for="product-price">Unit Price*</label>
                    <input type="number" id="product-price" step="0.01" min="0" required>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-primary" id="save-product">Save</button>
                    <button type="button" class="btn-danger" id="cancel-product">Cancel</button>
                </div>
            </form>
        `;
        modal.style.display = 'block';

        document.getElementById('cancel-product').addEventListener('click', () => {
            modal.style.display = 'none';
        });

        document.getElementById('save-product').addEventListener('click', () => {
            saveProduct();
        });
    });

    // Show Edit Product Form
    async function showEditProductForm(productId) {
        try {
            const response = await fetch(`${API_BASE_URL}/${productId}`);
            if (!response.ok) {
                throw new Error('Failed to fetch product');
            }
            const product = await response.json();
            
            currentProductId = productId;
            modalTitle.textContent = 'Edit Product';
            modalBody.innerHTML = `
                <form id="product-form">
                    <div class="form-group">
                        <label for="product-name">Product Name*</label>
                        <input type="text" id="product-name" value="${product.ProductName}" required>
                    </div>
                    <div class="form-group">
                        <label for="product-description">Description</label>
                        <textarea id="product-description" rows="3">${product.PDescription || ''}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="product-category">Category</label>
                        <input type="text" id="product-category" value="${product.Category || ''}">
                    </div>
                    <div class="form-group">
                        <label for="product-price">Unit Price*</label>
                        <input type="number" id="product-price" step="0.01" min="0" value="${product.UnitPrice}" required>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn-primary" id="save-product">Save</button>
                        <button type="button" class="btn-danger" id="cancel-product">Cancel</button>
                    </div>
                </form>
            `;
            modal.style.display = 'block';

            document.getElementById('cancel-product').addEventListener('click', () => {
                modal.style.display = 'none';
            });

            document.getElementById('save-product').addEventListener('click', () => {
                saveProduct();
            });
        } catch (error) {
            console.error('Error fetching product:', error);
            alert('Error loading product for editing. Please check console for details.');
        }
    }

    // Save Product (Create or Update)
    async function saveProduct() {
        const productData = {
            ProductName: document.getElementById('product-name').value,
            PDescription: document.getElementById('product-description').value || null,
            Category: document.getElementById('product-category').value || null,
            UnitPrice: parseFloat(document.getElementById('product-price').value)
        };

        if (!productData.ProductName || isNaN(productData.UnitPrice)) {
            alert('Please fill in all required fields');
            return;
        }

        try {
            let response;
            if (currentProductId) {
                // Update existing product
                response = await fetch(`${API_BASE_URL}/${currentProductId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(productData)
                });
            } else {
                // Create new product
                response = await fetch(API_BASE_URL, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(productData)
                });
            }

            if (!response.ok) {
                throw new Error(`Failed to ${currentProductId ? 'update' : 'create'} product`);
            }

            const result = await response.json();
            console.log('Product saved:', result);
            modal.style.display = 'none';
            fetchProducts();
        } catch (error) {
            console.error('Error saving product:', error);
            alert(`Error ${currentProductId ? 'updating' : 'creating'} product. Please check console for details.`);
        }
    }

    // Delete Product
    async function deleteProduct(productId) {
        if (!confirm('Are you sure you want to delete this product?')) {
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/${productId}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Failed to delete product');
            }

            console.log('Product deleted successfully');
            fetchProducts();
        } catch (error) {
            console.error('Error deleting product:', error);
            alert('Error deleting product. Please check console for details.');
        }
    }

    // Initialize the page by loading products
    fetchProducts();
});






/////////////////////////////////////////////////////////////














document.addEventListener('DOMContentLoaded', function() {
    // API Base URL
    const API_BASE_URL = 'http://localhost:5000/api';

    // DOM Elements
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const closeBtn = document.querySelector('.close-btn');
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    // Initialize the page
    initTabs();
    initModal();
    loadSuppliers();

    // Tab Switching Functionality
    function initTabs() {
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Update active tab
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                button.classList.add('active');
                
                const tabId = button.getAttribute('data-tab');
                document.getElementById(tabId).classList.add('active');
                
                // Load data if suppliers tab
                if (tabId === 'suppliers') {
                    loadSuppliers();
                }
            });
        });
    }

    // Modal Functionality
    function initModal() {
        closeBtn.addEventListener('click', () => modal.style.display = 'none');
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    }

    // Load Suppliers from API
    async function loadSuppliers() {
        try {
            showLoader('suppliers-table-body');
            const response = await fetch(`${API_BASE_URL}/suppliers`);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to fetch suppliers');
            }
            
            const suppliers = await response.json();
            populateSuppliersTable(suppliers);
        } catch (error) {
            console.error('Error loading suppliers:', error);
            showError('suppliers-table-body', error.message);
        }
    }

    // Show loader animation
    function showLoader(tableId) {
        const tableBody = document.getElementById(tableId);
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" class="loading-cell">
                    <div class="loader"></div>
                    <span>Loading data...</span>
                </td>
            </tr>
        `;
    }

    // Show error message
    function showError(tableId, message) {
        const tableBody = document.getElementById(tableId);
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" class="error-cell">
                    <span>${message}</span>
                    <button class="btn-primary" onclick="location.reload()">Retry</button>
                </td>
            </tr>
        `;
    }

    // Populate Suppliers Table
    function populateSuppliersTable(suppliers) {
        const tableBody = document.getElementById('suppliers-table-body');
        
        if (suppliers.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="8" class="empty-cell">No suppliers found</td>
                </tr>
            `;
            return;
        }
        
        tableBody.innerHTML = '';
        
        suppliers.forEach(supplier => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${supplier.SupplierID}</td>
                <td>${supplier.SupplierName}</td>
                <td>${supplier.ContactName || 'N/A'}</td>
                <td>${supplier.Address || 'N/A'}</td>
                <td>${supplier.City || 'N/A'}</td>
                <td>${supplier.Phone || 'N/A'}</td>
                <td>${supplier.Email || 'N/A'}</td>
                <td>
                    <button class="btn-primary edit-btn" data-id="${supplier.SupplierID}">Edit</button>
                    <button class="btn-danger delete-btn" data-id="${supplier.SupplierID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });

        // Add event listeners to new buttons
        addEditButtonListeners();
        addDeleteButtonListeners();
    }

    // Add Supplier Form
    document.getElementById('add-supplier-btn').addEventListener('click', () => {
        showSupplierForm();
    });

    function showSupplierForm(supplier = null) {
        const isEditMode = supplier !== null;
        modalTitle.textContent = isEditMode ? 'Edit Supplier' : 'Add New Supplier';
        
        modalBody.innerHTML = `
            <form id="supplier-form">
                <div class="form-group">
                    <label for="supplier-name">Supplier Name*</label>
                    <input type="text" id="supplier-name" value="${isEditMode ? supplier.SupplierName : ''}" required>
                </div>
                <div class="form-group">
                    <label for="contact-name">Contact Name</label>
                    <input type="text" id="contact-name" value="${isEditMode ? supplier.ContactName || '' : ''}">
                </div>
                <div class="form-group">
                    <label for="supplier-address">Address</label>
                    <input type="text" id="supplier-address" value="${isEditMode ? supplier.Address || '' : ''}">
                </div>
                <div class="form-group">
                    <label for="supplier-city">City</label>
                    <input type="text" id="supplier-city" value="${isEditMode ? supplier.City || '' : ''}">
                </div>
                <div class="form-group">
                    <label for="supplier-phone">Phone</label>
                    <input type="text" id="supplier-phone" value="${isEditMode ? supplier.Phone || '' : ''}">
                </div>
                <div class="form-group">
                    <label for="supplier-email">Email</label>
                    <input type="email" id="supplier-email" value="${isEditMode ? supplier.Email || '' : ''}">
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-primary" id="save-supplier">
                        ${isEditMode ? 'Update' : 'Save'}
                    </button>
                    <button type="button" class="btn-danger" id="cancel-supplier">Cancel</button>
                </div>
            </form>
        `;
        
        modal.style.display = 'block';

        document.getElementById('cancel-supplier').addEventListener('click', () => {
            modal.style.display = 'none';
        });

        document.getElementById('save-supplier').addEventListener('click', async () => {
            const supplierData = {
                SupplierName: document.getElementById('supplier-name').value.trim(),
                ContactName: document.getElementById('contact-name').value.trim() || null,
                Address: document.getElementById('supplier-address').value.trim() || null,
                City: document.getElementById('supplier-city').value.trim() || null,
                Phone: document.getElementById('supplier-phone').value.trim() || null,
                Email: document.getElementById('supplier-email').value.trim() || null
            };

            if (!supplierData.SupplierName) {
                alert('Supplier Name is required');
                return;
            }

            try {
                if (isEditMode) {
                    await updateSupplier(supplier.SupplierID, supplierData);
                } else {
                    await createSupplier(supplierData);
                }
                modal.style.display = 'none';
                loadSuppliers();
            } catch (error) {
                console.error('Error saving supplier:', error);
                alert(`Error: ${error.message}`);
            }
        });
    }

    async function createSupplier(supplierData) {
        const response = await fetch(`${API_BASE_URL}/suppliers`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(supplierData)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.details || errorData.error || 'Failed to create supplier');
        }
    }

    async function updateSupplier(supplierId, supplierData) {
        const response = await fetch(`${API_BASE_URL}/suppliers/${supplierId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(supplierData)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.details || errorData.error || 'Failed to update supplier');
        }
    }

    function addEditButtonListeners() {
        document.querySelectorAll('.edit-btn').forEach(button => {
            button.addEventListener('click', async () => {
                const supplierId = button.getAttribute('data-id');
                try {
                    const response = await fetch(`${API_BASE_URL}/suppliers/${supplierId}`);
                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || 'Failed to fetch supplier');
                    }
                    const supplier = await response.json();
                    showSupplierForm(supplier);
                } catch (error) {
                    console.error('Error fetching supplier:', error);
                    alert(`Error: ${error.message}`);
                }
            });
        });
    }

    function addDeleteButtonListeners() {
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', async () => {
                if (!confirm('Are you sure you want to delete this supplier?')) {
                    return;
                }
                
                const supplierId = button.getAttribute('data-id');
                try {
                    const response = await fetch(`${API_BASE_URL}/suppliers/${supplierId}`, {
                        method: 'DELETE'
                    });

                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || 'Failed to delete supplier');
                    }

                    loadSuppliers();
                } catch (error) {
                    console.error('Error deleting supplier:', error);
                    alert(`Error: ${error.message}`);
                }
            });
        });
    }
});



















/////////////////////////////////////////////////////////////////


document.addEventListener('DOMContentLoaded', function() {
    // API Base URL
    const API_BASE_URL = 'http://localhost:5000/api';

    // Get DOM elements
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const closeBtn = document.querySelector('.close-btn');

    // Tab switching functionality
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabId = button.getAttribute('data-tab');
            
            // Hide all tab contents
            tabContents.forEach(content => {
                content.classList.remove('active');
            });
            
            // Deactivate all tab buttons
            tabButtons.forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Activate current tab
            button.classList.add('active');
            document.getElementById(tabId).classList.add('active');
            
            // Load data for the active tab
            if (tabId === 'inventory') {
                loadInventory();
            }
            // Add other tab loaders here as needed
        });
    });

    // Modal functionality
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Helper functions
    function showLoader(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.innerHTML = '<tr><td colspan="100%" class="loading">Loading...</td></tr>';
        }
    }

    function showError(elementId, message) {
        const element = document.getElementById(elementId);
        if (element) {
            element.innerHTML = `<tr><td colspan="100%" class="error">Error: ${message}</td></tr>`;
        }
    }

    // Load Inventory from API
    async function loadInventory() {
        try {
            showLoader('inventory-table-body');
            const response = await fetch(`${API_BASE_URL}/inventory`);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to fetch inventory');
            }
            
            const inventory = await response.json();
            populateInventoryTable(inventory);
        } catch (error) {
            console.error('Error loading inventory:', error);
            showError('inventory-table-body', error.message);
        }
    }

    // Populate Inventory Table
    function populateInventoryTable(inventory) {
        const tableBody = document.getElementById('inventory-table-body');
        
        if (inventory.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="empty-cell">No inventory items found</td>
                </tr>
            `;
            return;
        }
        
        tableBody.innerHTML = '';
        
        inventory.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.InventoryID}</td>
                <td>${item.ProductID} (${item.ProductName || 'N/A'})</td>
                <td>${item.QuantityInStock}</td>
                <td>${item.location || 'N/A'}</td>
                <td>
                    <button class="btn-primary edit-btn" data-id="${item.InventoryID}">Edit</button>
                    <button class="btn-danger delete-btn" data-id="${item.InventoryID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });

        // Add event listeners to new buttons
        addInventoryEditButtonListeners();
        addInventoryDeleteButtonListeners();
    }

    // Add Inventory Form
    document.getElementById('add-inventory-btn').addEventListener('click', async () => {
        try {
            // Fetch products for dropdown
            const productsResponse = await fetch(`${API_BASE_URL}/products`);
            if (!productsResponse.ok) {
                throw new Error('Failed to fetch products');
            }
            const products = await productsResponse.json();

            modalTitle.textContent = 'Add Inventory Item';
            modalBody.innerHTML = `
                <form id="inventory-form">
                    <div class="form-group">
                        <label for="inventory-product">Product*</label>
                        <select id="inventory-product" required>
                            <option value="">Select Product</option>
                            ${products.map(p => 
                                `<option value="${p.ProductID}">${p.ProductID} - ${p.ProductName}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="inventory-quantity">Quantity*</label>
                        <input type="number" id="inventory-quantity" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="inventory-location">Location</label>
                        <input type="text" id="inventory-location">
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn-primary" id="save-inventory">Save</button>
                        <button type="button" class="btn-danger" id="cancel-inventory">Cancel</button>
                    </div>
                </form>
            `;
            modal.style.display = 'block';

            document.getElementById('cancel-inventory').addEventListener('click', () => {
                modal.style.display = 'none';
            });

            document.getElementById('save-inventory').addEventListener('click', async () => {
                const productId = document.getElementById('inventory-product').value;
                const quantity = document.getElementById('inventory-quantity').value;
                
                if (!productId || !quantity) {
                    alert('Please fill in all required fields');
                    return;
                }

                const newInventory = {
                    ProductID: parseInt(productId),
                    QuantityInStock: parseInt(quantity),
                    location: document.getElementById('inventory-location').value || null
                };
                
                try {
                    const response = await fetch(`${API_BASE_URL}/inventory`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(newInventory)
                    });

                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.details || errorData.error || 'Failed to create inventory item');
                    }

                    loadInventory();
                    modal.style.display = 'none';
                } catch (error) {
                    console.error('Error creating inventory:', error);
                    alert(`Error: ${error.message}`);
                }
            });
        } catch (error) {
            console.error('Error loading product list:', error);
            alert(`Error: ${error.message}`);
        }
    });

    function addInventoryEditButtonListeners() {
        document.querySelectorAll('#inventory-table-body .edit-btn').forEach(button => {
            button.addEventListener('click', async () => {
                const inventoryId = button.getAttribute('data-id');
                try {
                    // Fetch inventory item details
                    const inventoryResponse = await fetch(`${API_BASE_URL}/inventory/${inventoryId}`);
                    if (!inventoryResponse.ok) {
                        throw new Error('Failed to fetch inventory item');
                    }
                    const inventoryItem = await inventoryResponse.json();

                    // Fetch products for dropdown
                    const productsResponse = await fetch(`${API_BASE_URL}/products`);
                    if (!productsResponse.ok) {
                        throw new Error('Failed to fetch products');
                    }
                    const products = await productsResponse.json();

                    modalTitle.textContent = 'Edit Inventory Item';
                    modalBody.innerHTML = `
                        <form id="inventory-form">
                            <div class="form-group">
                                <label for="inventory-product">Product*</label>
                                <select id="inventory-product" required>
                                    <option value="">Select Product</option>
                                    ${products.map(p => 
                                        `<option value="${p.ProductID}" ${p.ProductID === inventoryItem.ProductID ? 'selected' : ''}>
                                            ${p.ProductID} - ${p.ProductName}
                                        </option>`
                                    ).join('')}
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="inventory-quantity">Quantity*</label>
                                <input type="number" id="inventory-quantity" 
                                       value="${inventoryItem.QuantityInStock}" 
                                       min="0" required>
                            </div>
                            <div class="form-group">
                                <label for="inventory-location">Location</label>
                                <input type="text" id="inventory-location" 
                                       value="${inventoryItem.location || ''}">
                            </div>
                            <div class="form-actions">
                                <button type="button" class="btn-primary" id="update-inventory">Update</button>
                                <button type="button" class="btn-danger" id="cancel-inventory">Cancel</button>
                            </div>
                        </form>
                    `;
                    modal.style.display = 'block';

                    document.getElementById('cancel-inventory').addEventListener('click', () => {
                        modal.style.display = 'none';
                    });

                    document.getElementById('update-inventory').addEventListener('click', async () => {
                        const productId = document.getElementById('inventory-product').value;
                        const quantity = document.getElementById('inventory-quantity').value;
                        
                        if (!productId || !quantity) {
                            alert('Please fill in all required fields');
                            return;
                        }

                        const updatedInventory = {
                            ProductID: parseInt(productId),
                            QuantityInStock: parseInt(quantity),
                            location: document.getElementById('inventory-location').value || null
                        };
                        
                        try {
                            const response = await fetch(`${API_BASE_URL}/inventory/${inventoryId}`, {
                                method: 'PUT',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(updatedInventory)
                            });

                            if (!response.ok) {
                                const errorData = await response.json();
                                throw new Error(errorData.details || errorData.error || 'Failed to update inventory item');
                            }

                            loadInventory();
                            modal.style.display = 'none';
                        } catch (error) {
                            console.error('Error updating inventory:', error);
                            alert(`Error: ${error.message}`);
                        }
                    });
                } catch (error) {
                    console.error('Error loading inventory data:', error);
                    alert(`Error: ${error.message}`);
                }
            });
        });
    }

    function addInventoryDeleteButtonListeners() {
        document.querySelectorAll('#inventory-table-body .delete-btn').forEach(button => {
            button.addEventListener('click', async () => {
                if (!confirm('Are you sure you want to delete this inventory item?')) {
                    return;
                }
                
                const inventoryId = button.getAttribute('data-id');
                try {
                    const response = await fetch(`${API_BASE_URL}/inventory/${inventoryId}`, {
                        method: 'DELETE'
                    });

                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || 'Failed to delete inventory item');
                    }

                    loadInventory();
                } catch (error) {
                    console.error('Error deleting inventory:', error);
                    alert(`Error: ${error.message}`);
                }
            });
        });
    }

    // Initialize the page
    loadInventory();
});













///////////////////////////////////////////////////////////////////////////////////



document.addEventListener('DOMContentLoaded', function() {
    // Tab Switching Functionality
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            button.classList.add('active');
            const tabId = button.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
            
            // Refresh data when switching tabs
            if (tabId === 'customers') {
                fetchCustomers();
            }
        });
    });

    // Modal Functionality
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const closeBtn = document.querySelector('.close-btn');
    
    closeBtn.addEventListener('click', () => modal.style.display = 'none');
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // API Base URL
    const API_BASE_URL = 'http://localhost:5000/api';

    // Customers Functions
    async function fetchCustomers() {
        try {
            const response = await fetch(`${API_BASE_URL}/customers`);
            if (!response.ok) {
                throw new Error('Failed to fetch customers');
            }
            const customers = await response.json();
            populateCustomersTable(customers);
        } catch (error) {
            console.error('Error fetching customers:', error);
            alert('Error loading customers. Please try again.');
        }
    }

    function populateCustomersTable(customers) {
        const tableBody = document.getElementById('customers-table-body');
        tableBody.innerHTML = '';
        
        customers.forEach(customer => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${customer.CustomerID}</td>
                <td>${customer.CustomerName}</td>
                <td>${customer.ContactName || 'N/A'}</td>
                <td>${customer.Email || 'N/A'}</td>
                <td>${customer.Phone || 'N/A'}</td>
                <td>
                    <button class="btn-primary edit-btn" data-id="${customer.CustomerID}">Edit</button>
                    <button class="btn-danger delete-btn" data-id="${customer.CustomerID}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    // Add Customer Form
    document.getElementById('add-customer-btn').addEventListener('click', () => {
        modalTitle.textContent = 'Add New Customer';
        modalBody.innerHTML = `
            <form id="customer-form">
                <div class="form-group">
                    <label for="customer-name">Customer Name*</label>
                    <input type="text" id="customer-name" required>
                </div>
                <div class="form-group">
                    <label for="contact-name">Contact Name</label>
                    <input type="text" id="contact-name">
                </div>
                <div class="form-group">
                    <label for="customer-email">Email</label>
                    <input type="email" id="customer-email">
                </div>
                <div class="form-group">
                    <label for="customer-phone">Phone</label>
                    <input type="text" id="customer-phone">
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-primary" id="save-customer">Save</button>
                    <button type="button" class="btn-danger" id="cancel-customer">Cancel</button>
                </div>
            </form>
        `;
        modal.style.display = 'block';

        document.getElementById('cancel-customer').addEventListener('click', () => {
            modal.style.display = 'none';
        });

        document.getElementById('save-customer').addEventListener('click', async () => {
            const customerName = document.getElementById('customer-name').value;
            if (!customerName) {
                alert('Customer Name is required');
                return;
            }

            const newCustomer = {
                CustomerName: customerName,
                ContactName: document.getElementById('contact-name').value || null,
                Email: document.getElementById('customer-email').value || null,
                Phone: document.getElementById('customer-phone').value || null
            };

            try {
                const response = await fetch(`${API_BASE_URL}/customers`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(newCustomer)
                });

                if (!response.ok) {
                    throw new Error('Failed to create customer');
                }

                const result = await response.json();
                alert('Customer created successfully');
                modal.style.display = 'none';
                fetchCustomers();
            } catch (error) {
                console.error('Error creating customer:', error);
                alert('Error creating customer. Please try again.');
            }
        });
    });

    // Edit Customer
    document.addEventListener('click', async function(e) {
        if (e.target.classList.contains('edit-btn')) {
            const customerId = e.target.getAttribute('data-id');
            
            try {
                const response = await fetch(`${API_BASE_URL}/customers/${customerId}`);
                if (!response.ok) {
                    throw new Error('Failed to fetch customer');
                }
                const customer = await response.json();

                modalTitle.textContent = 'Edit Customer';
                modalBody.innerHTML = `
                    <form id="edit-customer-form">
                        <div class="form-group">
                            <label for="edit-customer-name">Customer Name*</label>
                            <input type="text" id="edit-customer-name" value="${customer.CustomerName}" required>
                        </div>
                        <div class="form-group">
                            <label for="edit-contact-name">Contact Name</label>
                            <input type="text" id="edit-contact-name" value="${customer.ContactName || ''}">
                        </div>
                        <div class="form-group">
                            <label for="edit-customer-email">Email</label>
                            <input type="email" id="edit-customer-email" value="${customer.Email || ''}">
                        </div>
                        <div class="form-group">
                            <label for="edit-customer-phone">Phone</label>
                            <input type="text" id="edit-customer-phone" value="${customer.Phone || ''}">
                        </div>
                        <div class="form-actions">
                            <button type="button" class="btn-primary" id="update-customer">Update</button>
                            <button type="button" class="btn-danger" id="cancel-edit">Cancel</button>
                        </div>
                    </form>
                `;
                modal.style.display = 'block';

                document.getElementById('cancel-edit').addEventListener('click', () => {
                    modal.style.display = 'none';
                });

                document.getElementById('update-customer').addEventListener('click', async () => {
                    const customerName = document.getElementById('edit-customer-name').value;
                    if (!customerName) {
                        alert('Customer Name is required');
                        return;
                    }

                    const updatedCustomer = {
                        CustomerName: customerName,
                        ContactName: document.getElementById('edit-contact-name').value || null,
                        Email: document.getElementById('edit-customer-email').value || null,
                        Phone: document.getElementById('edit-customer-phone').value || null
                    };

                    try {
                        const response = await fetch(`${API_BASE_URL}/customers/${customerId}`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify(updatedCustomer)
                        });

                        if (!response.ok) {
                            throw new Error('Failed to update customer');
                        }

                        alert('Customer updated successfully');
                        modal.style.display = 'none';
                        fetchCustomers();
                    } catch (error) {
                        console.error('Error updating customer:', error);
                        alert('Error updating customer. Please try again.');
                    }
                });
            } catch (error) {
                console.error('Error fetching customer:', error);
                alert('Error loading customer data. Please try again.');
            }
        }
    });

    // Delete Customer
    document.addEventListener('click', async function(e) {
        if (e.target.classList.contains('delete-btn')) {
            if (!confirm('Are you sure you want to delete this customer?')) {
                return;
            }

            const customerId = e.target.getAttribute('data-id');
            
            try {
                const response = await fetch(`${API_BASE_URL}/customers/${customerId}`, {
                    method: 'DELETE'
                });

                if (!response.ok) {
                    throw new Error('Failed to delete customer');
                }

                alert('Customer deleted successfully');
                fetchCustomers();
            } catch (error) {
                console.error('Error deleting customer:', error);
                alert('Error deleting customer. Please try again.');
            }
        }
    });

    // Initialize the page - load customers data
    fetchCustomers();
});











