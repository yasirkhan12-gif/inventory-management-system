require("dotenv").config();
const sql = require("mssql");

// Configuration object
const config = {
  server: process.env.DB_SERVER,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    trustServerCertificate: true, // required for local/dev with self-signed certs
  },
};

// Create a pool and export it
const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(pool => {
    console.log("✅ Connected to SQL Server");
    return pool;
  })
  .catch(err => {
    console.error("❌ Database connection failed!", err);
    throw err;
  });

module.exports = {
  sql,
  poolPromise,
};
