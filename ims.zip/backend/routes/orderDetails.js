const express = require('express');
const router = express.Router();
const orderDetailsController = require('../controllers/orderDetailsController');

router.get('/', orderDetailsController.getAllOrderDetails);
router.get('/:id', orderDetailsController.getOrderDetailsById);
router.post('/', orderDetailsController.createOrderDetail);
router.put('/:id', orderDetailsController.updateOrderDetail);
router.delete('/:id', orderDetailsController.deleteOrderDetail);

module.exports = router;