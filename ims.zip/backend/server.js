require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { poolPromise } = require("./db");

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
const productsRoutes = require('./routes/products');
const suppliersRoutes = require('./routes/suppliers');
const inventoryRoutes = require('./routes/inventory');
const customersRoutes = require('./routes/customers');
const purchaseOrdersRoutes = require('./routes/purchaseOrders');
const salesOrdersRoutes = require('./routes/salesOrders');
const orderDetailsRoutes = require('./routes/orderDetails');

app.use('/api/products', productsRoutes);
app.use('/api/suppliers', suppliersRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/customers', customersRoutes);
app.use('/api/purchase-orders', purchaseOrdersRoutes);
app.use('/api/sales-orders', salesOrdersRoutes);
app.use('/api/order-details', orderDetailsRoutes);

// Catch-all for unknown routes
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server after DB connection
(async () => {
  try {
    await poolPromise;
    app.listen(port, () => console.log(`Server running on port ${port}`));
  } catch (error) {
    console.error('Failed to connect to database:', error.message);
    process.exit(1);
  }
})();
