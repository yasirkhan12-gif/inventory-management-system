const { sql, poolPromise } = require('../db');

const getAllSalesOrders = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query('SELECT * FROM SalesOrders');
    res.json(result.recordset);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getSalesOrderById = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('OrderID', sql.Int, req.params.id)
      .query('SELECT * FROM SalesOrders WHERE OrderID = @OrderID');

    if (result.recordset.length === 0) {
      return res.status(404).json({ error: 'Sales order not found' });
    }

    res.json(result.recordset[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const createSalesOrder = async (req, res) => {
  const { OrderID, CustomerID, TotalAmount } = req.body;
  try {
    const pool = await poolPromise;
    await pool.request()
      .input('OrderID', sql.Int, OrderID)
      .input('CustomerID', sql.Int, CustomerID)
      .input('TotalAmount', sql.Decimal(18, 2), TotalAmount)
      .query(`
        INSERT INTO SalesOrders (OrderID, CustomerID, TotalAmount)
        VALUES (@OrderID, @CustomerID, @TotalAmount)
      `);

    res.status(201).json({ message: 'Sales order created successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateSalesOrder = async (req, res) => {
  const { CustomerID, TotalAmount } = req.body;
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('OrderID', sql.Int, req.params.id)
      .input('CustomerID', sql.Int, CustomerID)
      .input('TotalAmount', sql.Decimal(18, 2), TotalAmount)
      .query(`
        UPDATE SalesOrders
        SET CustomerID = @CustomerID,
            TotalAmount = @TotalAmount
        WHERE OrderID = @OrderID
      `);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Sales order not found' });
    }

    res.json({ message: 'Sales order updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteSalesOrder = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('OrderID', sql.Int, req.params.id)
      .query('DELETE FROM SalesOrders WHERE OrderID = @OrderID');

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Sales order not found' });
    }

    res.json({ message: 'Sales order deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  getAllSalesOrders,
  getSalesOrderById,
  createSalesOrder,
  updateSalesOrder,
  deleteSalesOrder
};
