const { sql, poolPromise } = require('../db');

const getAllProducts = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query('SELECT * FROM Products');
    res.json(result.recordset);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ 
      error: 'Failed to fetch products',
      details: error.message 
    });
  }
};

const getProductById = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('ProductID', sql.Int, req.params.id)
      .query('SELECT * FROM Products WHERE ProductID = @ProductID');

    if (result.recordset.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json(result.recordset[0]);
  } catch (error) {
    console.error('Error fetching product:', error);
    res.status(500).json({ 
      error: 'Failed to fetch product',
      details: error.message 
    });
  }
};

const createProduct = async (req, res) => {
  const { ProductName, PDescription, Category, UnitPrice } = req.body;
  
  if (!ProductName || UnitPrice === undefined) {
    return res.status(400).json({ error: 'ProductName and UnitPrice are required' });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('ProductName', sql.NVarChar(100), ProductName)
      .input('PDescription', sql.NVarChar(255), PDescription || null)
      .input('Category', sql.NVarChar(100), Category || null)
      .input('UnitPrice', sql.Decimal(18, 2), UnitPrice)
      .query(`
        INSERT INTO Products (ProductName, PDescription, Category, UnitPrice)
        OUTPUT INSERTED.*
        VALUES (@ProductName, @PDescription, @Category, @UnitPrice)
      `);

    res.status(201).json(result.recordset[0]);
  } catch (error) {
    console.error('Product creation error:', error);
    res.status(500).json({ 
      error: 'Failed to create product',
      details: error.message 
    });
  }
};

const updateProduct = async (req, res) => {
  const { ProductName, PDescription, Category, UnitPrice } = req.body;
  
  if (!ProductName || UnitPrice === undefined) {
    return res.status(400).json({ error: 'ProductName and UnitPrice are required' });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('ProductID', sql.Int, req.params.id)
      .input('ProductName', sql.NVarChar(100), ProductName)
      .input('PDescription', sql.NVarChar(255), PDescription || null)
      .input('Category', sql.NVarChar(100), Category || null)
      .input('UnitPrice', sql.Decimal(18, 2), UnitPrice)
      .query(`
        UPDATE Products
        SET ProductName = @ProductName,
            PDescription = @PDescription,
            Category = @Category,
            UnitPrice = @UnitPrice
        WHERE ProductID = @ProductID
      `);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    // Return the updated product
    const updatedProduct = await pool.request()
      .input('ProductID', sql.Int, req.params.id)
      .query('SELECT * FROM Products WHERE ProductID = @ProductID');

    res.json(updatedProduct.recordset[0]);
  } catch (error) {
    console.error('Product update error:', error);
    res.status(500).json({ 
      error: 'Failed to update product',
      details: error.message 
    });
  }
};

const deleteProduct = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('ProductID', sql.Int, req.params.id)
      .query('DELETE FROM Products WHERE ProductID = @ProductID');

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json({ 
      message: 'Product deleted successfully',
      ProductID: req.params.id
    });
  } catch (error) {
    console.error('Product deletion error:', error);
    res.status(500).json({ 
      error: 'Failed to delete product',
      details: error.message 
    });
  }
};

module.exports = {
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct
};