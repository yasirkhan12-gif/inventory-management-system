const { sql, poolPromise } = require('../db');

const getAllPurchaseOrders = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`
      SELECT po.OrderID, po.SupplierID, s.SupplierName, po.TotalAmount 
      FROM PurchaseOrders po
      JOIN Suppliers s ON po.SupplierID = s.SupplierID
    `);
    res.json(result.recordset);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getPurchaseOrderById = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('OrderID', sql.Int, req.params.id)
      .query(`
        SELECT po.OrderID, po.SupplierID, s.SupplierName, po.TotalAmount 
        FROM PurchaseOrders po
        JOIN Suppliers s ON po.SupplierID = s.SupplierID
        WHERE po.OrderID = @OrderID
      `);

    if (result.recordset.length === 0) {
      return res.status(404).json({ error: 'Purchase order not found' });
    }

    res.json(result.recordset[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const createPurchaseOrder = async (req, res) => {
  const { SupplierID, TotalAmount } = req.body;
  
  if (!SupplierID || !TotalAmount) {
    return res.status(400).json({ error: 'SupplierID and TotalAmount are required' });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('SupplierID', sql.Int, SupplierID)
      .input('TotalAmount', sql.Decimal(18, 2), TotalAmount)
      .query(`
        INSERT INTO PurchaseOrders (SupplierID, TotalAmount)
        OUTPUT INSERTED.OrderID
        VALUES (@SupplierID, @TotalAmount)
      `);

    res.status(201).json({ 
      message: 'Purchase order created successfully',
      orderID: result.recordset[0].OrderID
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updatePurchaseOrder = async (req, res) => {
  const { SupplierID, TotalAmount } = req.body;
  
  if (!SupplierID || !TotalAmount) {
    return res.status(400).json({ error: 'SupplierID and TotalAmount are required' });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('OrderID', sql.Int, req.params.id)
      .input('SupplierID', sql.Int, SupplierID)
      .input('TotalAmount', sql.Decimal(18, 2), TotalAmount)
      .query(`
        UPDATE PurchaseOrders
        SET SupplierID = @SupplierID,
            TotalAmount = @TotalAmount
        WHERE OrderID = @OrderID
      `);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Purchase order not found' });
    }

    res.json({ message: 'Purchase order updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deletePurchaseOrder = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('OrderID', sql.Int, req.params.id)
      .query('DELETE FROM PurchaseOrders WHERE OrderID = @OrderID');

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Purchase order not found' });
    }

    res.json({ message: 'Purchase order deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  getAllPurchaseOrders,
  getPurchaseOrderById,
  createPurchaseOrder,
  updatePurchaseOrder,
  deletePurchaseOrder
};