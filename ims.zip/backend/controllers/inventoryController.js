const { sql, poolPromise } = require('../db');

const getAllInventory = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`
      SELECT i.*, p.ProductName 
      FROM Inventory i
      LEFT JOIN Products p ON i.ProductID = p.ProductID
    `);
    res.json(result.recordset);
  } catch (error) {
    console.error('Error fetching inventory:', error);
    res.status(500).json({ 
      error: 'Failed to fetch inventory',
      details: error.message 
    });
  }
};

const getInventoryById = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('InventoryID', sql.Int, req.params.id)
      .query(`
        SELECT i.*, p.ProductName 
        FROM Inventory i
        LEFT JOIN Products p ON i.ProductID = p.ProductID
        WHERE i.InventoryID = @InventoryID
      `);

    if (result.recordset.length === 0) {
      return res.status(404).json({ error: 'Inventory item not found' });
    }
    res.json(result.recordset[0]);
  } catch (error) {
    console.error('Error fetching inventory item:', error);
    res.status(500).json({ 
      error: 'Failed to fetch inventory item',
      details: error.message 
    });
  }
};

const createInventory = async (req, res) => {
  const { ProductID, QuantityInStock, location } = req.body;
  
  // Validate required fields
  if (!ProductID || QuantityInStock === undefined) {
    return res.status(400).json({ 
      error: 'ProductID and QuantityInStock are required' 
    });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('ProductID', sql.Int, ProductID)
      .input('QuantityInStock', sql.Int, QuantityInStock)
      .input('location', sql.VarChar(60), location || null)
      .query(`
        INSERT INTO Inventory (ProductID, QuantityInStock, location)
        OUTPUT INSERTED.*
        VALUES (@ProductID, @QuantityInStock, @location)
      `);

    res.status(201).json(result.recordset[0]);
  } catch (error) {
    console.error('Error creating inventory:', error);
    res.status(500).json({ 
      error: 'Failed to create inventory item',
      details: error.message,
      sqlError: error.originalError?.info?.message 
    });
  }
};

const updateInventory = async (req, res) => {
  const { ProductID, QuantityInStock, location } = req.body;
  
  // Validate required fields
  if (!ProductID || QuantityInStock === undefined) {
    return res.status(400).json({ 
      error: 'ProductID and QuantityInStock are required' 
    });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('InventoryID', sql.Int, req.params.id)
      .input('ProductID', sql.Int, ProductID)
      .input('QuantityInStock', sql.Int, QuantityInStock)
      .input('location', sql.VarChar(60), location || null)
      .query(`
        UPDATE Inventory
        SET ProductID = @ProductID,
            QuantityInStock = @QuantityInStock,
            location = @location
        WHERE InventoryID = @InventoryID
      `);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Inventory item not found' });
    }
    res.json({ message: 'Inventory updated successfully' });
  } catch (error) {
    console.error('Error updating inventory:', error);
    res.status(500).json({ 
      error: 'Failed to update inventory item',
      details: error.message 
    });
  }
};

const deleteInventory = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('InventoryID', sql.Int, req.params.id)
      .query('DELETE FROM Inventory WHERE InventoryID = @InventoryID');

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Inventory item not found' });
    }
    res.json({ message: 'Inventory deleted successfully' });
  } catch (error) {
    console.error('Error deleting inventory:', error);
    res.status(500).json({ 
      error: 'Failed to delete inventory item',
      details: error.message 
    });
  }
};

module.exports = {
  getAllInventory,
  getInventoryById,
  createInventory,
  updateInventory,
  deleteInventory
};