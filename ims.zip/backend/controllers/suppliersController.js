const { sql, poolPromise } = require('../db');

const getAllSuppliers = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query('SELECT * FROM Suppliers');
    res.json(result.recordset);
  } catch (error) {
    console.error('Error fetching suppliers:', error);
    res.status(500).json({ 
      error: 'Failed to fetch suppliers',
      details: error.message 
    });
  }
};

const getSupplierById = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('SupplierID', sql.Int, req.params.id)
      .query('SELECT * FROM Suppliers WHERE SupplierID = @SupplierID');

    if (result.recordset.length === 0) {
      return res.status(404).json({ error: 'Supplier not found' });
    }

    res.json(result.recordset[0]);
  } catch (error) {
    console.error('Error fetching supplier:', error);
    res.status(500).json({ 
      error: 'Failed to fetch supplier',
      details: error.message 
    });
  }
};

const createSupplier = async (req, res) => {
  // Remove SupplierID from destructuring to prevent accidental inclusion
  const { SupplierName, ContactName, Address, City, Phone, Email } = req.body;
  
  // Validate required fields
  if (!SupplierName) {
    return res.status(400).json({ error: 'SupplierName is required' });
  }

  try {
    const pool = await poolPromise;
    const request = pool.request()
      .input('SupplierName', sql.VarChar(100), SupplierName);
    
    // Add optional parameters only if they exist
    if (ContactName) request.input('ContactName', sql.VarChar(100), ContactName);
    if (Address) request.input('Address', sql.VarChar(200), Address);
    if (City) request.input('City', sql.VarChar(50), City);
    if (Phone) request.input('Phone', sql.VarChar(20), Phone);
    if (Email) request.input('Email', sql.VarChar(100), Email);

    // Build dynamic query that explicitly excludes SupplierID
    let columns = ['SupplierName'];
    let values = ['@SupplierName'];
    
    if (ContactName) { columns.push('ContactName'); values.push('@ContactName'); }
    if (Address) { columns.push('Address'); values.push('@Address'); }
    if (City) { columns.push('City'); values.push('@City'); }
    if (Phone) { columns.push('Phone'); values.push('@Phone'); }
    if (Email) { columns.push('Email'); values.push('@Email'); }
    
    const query = `
      INSERT INTO Suppliers (${columns.join(', ')})
      OUTPUT INSERTED.*
      VALUES (${values.join(', ')})
    `;

    const result = await request.query(query);

    res.status(201).json(result.recordset[0]);
  } catch (error) {
    console.error('Error creating supplier:', error);
    res.status(500).json({ 
      error: 'Failed to create supplier',
      details: error.message,
      sqlError: error.originalError?.info?.message 
    });
  }
};

const updateSupplier = async (req, res) => {
  const { SupplierName, ContactName, Address, City, Phone, Email } = req.body;
  
  if (!SupplierName) {
    return res.status(400).json({ error: 'SupplierName is required' });
  }

  try {
    const pool = await poolPromise;
    const request = pool.request()
      .input('SupplierID', sql.Int, req.params.id)
      .input('SupplierName', sql.VarChar(100), SupplierName);
    
    if (ContactName) request.input('ContactName', sql.VarChar(100), ContactName);
    if (Address) request.input('Address', sql.VarChar(200), Address);
    if (City) request.input('City', sql.VarChar(50), City);
    if (Phone) request.input('Phone', sql.VarChar(20), Phone);
    if (Email) request.input('Email', sql.VarChar(100), Email);

    let setClauses = ['SupplierName = @SupplierName'];
    if (ContactName) setClauses.push('ContactName = @ContactName');
    if (Address) setClauses.push('Address = @Address');
    if (City) setClauses.push('City = @City');
    if (Phone) setClauses.push('Phone = @Phone');
    if (Email) setClauses.push('Email = @Email');
    
    const query = `
      UPDATE Suppliers
      SET ${setClauses.join(', ')}
      WHERE SupplierID = @SupplierID
    `;

    const result = await request.query(query);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Supplier not found' });
    }

    res.json({ message: 'Supplier updated successfully' });
  } catch (error) {
    console.error('Error updating supplier:', error);
    res.status(500).json({ 
      error: 'Failed to update supplier',
      details: error.message 
    });
  }
};

const deleteSupplier = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('SupplierID', sql.Int, req.params.id)
      .query('DELETE FROM Suppliers WHERE SupplierID = @SupplierID');

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Supplier not found' });
    }

    res.json({ message: 'Supplier deleted successfully' });
  } catch (error) {
    console.error('Error deleting supplier:', error);
    res.status(500).json({ 
      error: 'Failed to delete supplier',
      details: error.message 
    });
  }
};

module.exports = {
  getAllSuppliers,
  getSupplierById,
  createSupplier,
  updateSupplier,
  deleteSupplier
};