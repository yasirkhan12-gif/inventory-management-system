const { sql, poolPromise } = require('../db');

const getAllOrderDetails = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query('SELECT * FROM orderDetails');
    res.json(result.recordset);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getOrderDetailsById = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('orderDetailID', sql.Int, req.params.id)
      .query('SELECT * FROM orderDetails WHERE orderDetailID = @orderDetailID');

    if (result.recordset.length === 0) {
      return res.status(404).json({ error: 'Order detail not found' });
    }

    res.json(result.recordset[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const createOrderDetail = async (req, res) => {
  const { orderDetailID, OrderID, ProductID, Quantity, UnitPrice } = req.body;
  try {
    const pool = await poolPromise;
    await pool.request()
      .input('orderDetailID', sql.Int, orderDetailID)
      .input('OrderID', sql.Int, OrderID)
      .input('ProductID', sql.Int, ProductID)
      .input('Quantity', sql.Int, Quantity)
      .input('UnitPrice', sql.Decimal(18, 2), UnitPrice)
      .query(`
        INSERT INTO orderDetails (orderDetailID, OrderID, ProductID, Quantity, UnitPrice)
        VALUES (@orderDetailID, @OrderID, @ProductID, @Quantity, @UnitPrice)
      `);

    res.status(201).json({ message: 'Order detail created successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateOrderDetail = async (req, res) => {
  const { OrderID, ProductID, Quantity, UnitPrice } = req.body;
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('orderDetailID', sql.Int, req.params.id)
      .input('OrderID', sql.Int, OrderID)
      .input('ProductID', sql.Int, ProductID)
      .input('Quantity', sql.Int, Quantity)
      .input('UnitPrice', sql.Decimal(18, 2), UnitPrice)
      .query(`
        UPDATE orderDetails
        SET OrderID = @OrderID,
            ProductID = @ProductID,
            Quantity = @Quantity,
            UnitPrice = @UnitPrice
        WHERE orderDetailID = @orderDetailID
      `);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Order detail not found' });
    }

    res.json({ message: 'Order detail updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteOrderDetail = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('orderDetailID', sql.Int, req.params.id)
      .query('DELETE FROM orderDetails WHERE orderDetailID = @orderDetailID');

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Order detail not found' });
    }

    res.json({ message: 'Order detail deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  getAllOrderDetails,
  getOrderDetailsById,
  createOrderDetail,
  updateOrderDetail,
  deleteOrderDetail
};
