const { sql, poolPromise } = require('../db');

const getAllCustomers = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query('SELECT * FROM Customers');
    res.json(result.recordset);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getCustomerById = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input('CustomerID', sql.Int, req.params.id)
      .query('SELECT * FROM Customers WHERE CustomerID = @CustomerID');

    if (result.recordset.length === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    res.json(result.recordset[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const createCustomer = async (req, res) => {
  const { CustomerName, ContactName, Email, Phone } = req.body;
  
  if (!CustomerName) {
    return res.status(400).json({ error: 'CustomerName is required' });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('CustomerName', sql.NVarChar, CustomerName)
      .input('ContactName', sql.NVarChar, ContactName || null)
      .input('Email', sql.NVarChar, Email || null)
      .input('Phone', sql.NVarChar, Phone || null)
      .query(`
        INSERT INTO Customers (CustomerName, ContactName, Email, Phone)
        OUTPUT INSERTED.CustomerID
        VALUES (@CustomerName, @ContactName, @Email, @Phone)
      `);

    res.status(201).json({ 
      message: 'Customer created successfully',
      CustomerID: result.recordset[0].CustomerID
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateCustomer = async (req, res) => {
  const { CustomerName, ContactName, Email, Phone } = req.body;
  
  if (!CustomerName) {
    return res.status(400).json({ error: 'CustomerName is required' });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('CustomerID', sql.Int, req.params.id)
      .input('CustomerName', sql.NVarChar, CustomerName)
      .input('ContactName', sql.NVarChar, ContactName || null)
      .input('Email', sql.NVarChar, Email || null)
      .input('Phone', sql.NVarChar, Phone || null)
      .query(`
        UPDATE Customers
        SET CustomerName = @CustomerName,
            ContactName = @ContactName,
            Email = @Email,
            Phone = @Phone
        WHERE CustomerID = @CustomerID
      `);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    res.json({ message: 'Customer updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteCustomer = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('CustomerID', sql.Int, req.params.id)
      .query('DELETE FROM Customers WHERE CustomerID = @CustomerID');

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    res.json({ message: 'Customer deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  getAllCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer
};